Map Originally Made By:
	-HG- Baby Seal Clubber

Map Converted By: 
	Vetter & Alt+F4

This Map Was Made For: 
	Breaking Point Call Of Duty 2 Tournament & Alt Internet Services

[=========================]
|  Vetter's Contact info  |
|=========================|
|xfire: swatcorv          |
|aim: swatcorv            |
|msn: swatcorv@gmail.com  |
|email: swatcorv@gmail.com|
[email: vetter@altis1.com ]<Business only plz

[=========================]
|  Alt+F4's Contact info  |
|=========================|
|xfire: altf4general      |
|email: alt@altis1.com.com|
[email: admin@bpcod2.com  ]



[=================================================]
|             Breaking Point's info               |
|=================================================|
|Website: www.bpcod2.com                          |
|Public Teamspeak: 69.59.183.236:8770 Pw: bpcod2  |
|Public and Battle Server: 64.247.18.219:28960    |
[Other Public and Battle Server: 69.64.35.52:28961]

[===============================]
|  Alt Internet Services Info   |
|===============================|
|Website: www.AltIs1.com        |
|email: vetter@altis1.com       |
[email: alt@altis1.com          ]

=========
Contains
-------
Townville

========
Gametypes Supported
-------
dm, tdm, hq, sd, ctf


How to install:
===============

1. If you dont have winrar please get it. Just google it.
2. Extract all .iwd files into c:/Activation/Call of Duty/main folder

Have Fun!!!!


� Alt Internet Services
� Breaking Point Community
